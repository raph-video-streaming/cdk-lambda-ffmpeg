"""
threefive.version
from the cli tool run: threefive version
"""

major = 3
minor = 0
maintenance = 59
version = f"{major}.{minor}.{maintenance}"
